package ucll.project.domain.user;

import ucll.project.domain.commendation.History;

import javax.net.ssl.HandshakeCompletedEvent;
import javax.servlet.http.HttpSession;
import javax.xml.bind.DatatypeConverter;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class User {
    private int userId;
    private String firstName;
    private String lastName;
    private String email;
    private Gender gender;
    private int stars;

public void setStars(int stars) {
    this.stars = stars;
}

public Integer getStars() {
    return stars;
}

private ArrayList<Role> roles = new ArrayList<>();


    // hashed password
    private transient String hashedPassword;

    public User() {
    }

    public User(String userName, String firstName, String lastName, String email, Gender gender, Role role, int remaining) {
        setFirstName(firstName);
        setLastName(lastName);
        setEmail(email);
        setGender(gender);
        setRole(role);
        setStars(remaining);
    }

    public void hashAndSetPassword(String password) {
        if (password.length() < 4) {
            throw new IllegalArgumentException("Too short password!");
        }
        String hashed = getPasswordToHashedPassword(password);
        setHashedPassword(hashed);
    }

    // This function will hash the password
    protected String getPasswordToHashedPassword(String password) {
        MessageDigest digest = null;
        try {
            digest = MessageDigest.getInstance("SHA-256");
        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException();
        }
        digest.update(password.getBytes(StandardCharsets.UTF_8));
        String hash = DatatypeConverter.printHexBinary(digest.digest()).toUpperCase();
        return hash;
    }

    public boolean isValidPassword(String password) {
        if (getHashedPassword() == null) {
            return false;
        }
        return getPasswordToHashedPassword(password).equals(getHashedPassword());
    }

    // Getters and setters and toString
    public int getUserId() {
        return this.userId;
    }

    public String getFirstName() {
        return this.firstName;
    }

    public String getLastName() {
        return this.lastName;
    }

    public String getEmail() {
        return this.email;
    }

    public Gender getGender() {
        return this.gender;
    }

    public ArrayList<Role> getRole() {
        return this.roles;
    }

    public String getHashedPassword() {
        return this.hashedPassword;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public void setEmail(String email) {
        Pattern pattern = Pattern.compile("[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,4}");
        Matcher mat = pattern.matcher(email);
        if (email.trim().isEmpty() || !mat.matches()) throw new IllegalArgumentException("invalid email");
        this.email = email;
    }

    public void setGender(Gender gender) {
        this.gender = gender;
    }

    public void setRole(Role role) {
        this.roles.add(role);
    }

    public void setRoles(ArrayList<Role> roles){this.roles.addAll(roles);}

    public void setHashedPassword(String hashedPassword) {
        this.hashedPassword = hashedPassword;
    }


    public void setIsAdmin(boolean getIsAdmin) {
    }

    public boolean getIsAdmin() {
        for (Role r:roles) {
            if (r.equals(Role.ADMIN)){
                return true;
            }
        }
        return false;
    }

    public boolean getIsManager(){
        for (Role r:roles) {
            if (r.equals(Role.MANAGER)){
                return true;
            }
        }
        return false;
    }

    public boolean getIsSuperUser() {
        for (Role r : roles) {
            if (r.equals(Role.SUPERUSER)) {
                return true;
            }
        }
        return false;
    }
}
