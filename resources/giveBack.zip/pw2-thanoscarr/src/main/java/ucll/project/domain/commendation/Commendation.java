package ucll.project.domain.commendation;

import io.cucumber.java.bs.A;

import java.util.ArrayList;
import java.util.List;

public class Commendation {
    private int id;
    private String description;
    private List<Tag> tag = new ArrayList<>();
    private int toEmployee;
    private int fromEmployee;

    public Commendation(){
    };

    public Commendation(int id,String description, Tag tag, int toEmployee, int fromEmployee){
        this.description = description;
        this.tag.add(tag);
        this.toEmployee = toEmployee;
        this.fromEmployee = fromEmployee;
        setId();
    }

    public void setId() {
        this.id = CommendationDb.getIdCount() + 1;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public void addTags(List<Tag> tags) {
        this.tag.addAll(tags);
    }

    public void addTag(Tag tag){
        this.tag.add(tag);
    }

    public void setToEmployee(int toEmployee) {
        this.toEmployee = toEmployee;
    }

    public void setFromEmployee(int fromEmployee) {
        this.fromEmployee = fromEmployee;
    }

    public int getId() {
        return id;
    }

    public String getDescription() {
        return description;
    }

    public List<Tag> getTags() {
        return this.tag;
    }

    public int getToEmployee() {
        return toEmployee;
    }

    public int getFromEmployee() {
        return fromEmployee;
    }
}
