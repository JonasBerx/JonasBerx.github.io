package ucll.project.ui.controller;


import org.apache.commons.io.FilenameUtils;
import org.apache.commons.io.IOUtils;
import ucll.project.db.ConnectionPool;
import ucll.project.domain.commendation.Commendation;
import ucll.project.domain.commendation.History;
import ucll.project.domain.user.Gender;
import ucll.project.domain.user.User;
import ucll.project.domain.user.Service;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.InputStream;
import java.sql.*;
import java.util.*;

public class Profile extends RequestHandler {
    public Profile(String command, Service userService) {
        super(command, userService);
    }

    @Override
    public void handleRequest(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        if (request.getSession().getAttribute("user") == null){
            request.getRequestDispatcher("login.jsp").forward(request, response);
        } else {
            if (request.getSession().getAttribute("user") == null){
                request.getRequestDispatcher("login.jsp").forward(request, response);
            } else {
                User user = (User) request.getSession().getAttribute("user");

                request.setAttribute("user", user);


                String email = user.getEmail();
                Gender gender = user.getGender();

                request.setAttribute("email", email);
                request.setAttribute("gender", gender);


                // TODO Show profile picture for current empl
                //Map<String, InputStream> imgs = getImgs();
                Map<String, InputStream> imgs = getImgByEmployeeId(user.getUserId());
                List<String> imgBase64 = new ArrayList<>();

                try {
                    for (Map.Entry<String, InputStream> entry : imgs.entrySet()) {
                        String extension = FilenameUtils.getExtension(entry.getKey());
                        byte[] encoded = Base64.getEncoder().encode(IOUtils.toByteArray(entry.getValue()));
                        imgBase64.add("data:image/" + extension + ";base64, " + new String(encoded));
                    }
                } catch (Exception e) {
                    System.out.println(e.getMessage());
                }
                request.setAttribute("imageUrlList", imgBase64);

                List<History> historyGiven = getUserService().getHistoryFrom(user.getFirstName());


                List<History> historyReceived = getUserService().getHistoryBy(user.getFirstName());

                request.setAttribute("commendationsReceivedList", historyReceived);
                request.setAttribute("commendationsGivenList", historyGiven);

                request.getRequestDispatcher("profile.jsp").forward(request, response);
            }
        }
    }

    // SHOW ALL PICTURES
    private Map<String, InputStream> getImgs() {
        Map<String, InputStream> imgs = new HashMap<>();

        String sql = "select image, image_content from avatar";
        try ( Connection connection = ConnectionPool.getConnection()){
            PreparedStatement stmt = connection.prepareStatement(sql);
            ResultSet resultSet = stmt.executeQuery();

            while (resultSet.next()) {
                String filename = resultSet.getString("image");
                InputStream fileContent = resultSet.getBinaryStream("image_content");
                imgs.put(filename, fileContent);
            }
        } catch (Exception e) {
            System.out.println(e.getMessage());
            throw new IllegalArgumentException(e);
        }
        return imgs;
    }
    // show picture per user
    private Map<String, InputStream> getImgByEmployeeId(int employeeId) {
        Map<String, InputStream> imgs = new HashMap<>();

        String sql = "select image, image_content from avatar where of_employee = ?";
        //String sql = "select image, image_content from avatar";
        try ( Connection connection = ConnectionPool.getConnection()){
            PreparedStatement stmt = connection.prepareStatement(sql);
            stmt.setInt(1, employeeId);
            ResultSet resultSet = stmt.executeQuery();

            while (resultSet.next()) {
                String filename = resultSet.getString("image");
                InputStream fileContent = resultSet.getBinaryStream("image_content");
                imgs.put(filename, fileContent);
            }
        } catch (Exception e) {
            System.out.println(e.getMessage());
            throw new IllegalArgumentException(e);
        }
        return imgs;
    }
}
