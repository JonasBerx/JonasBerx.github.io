package ucll.project.domain.commendation;

//import sun.security.util.PendingException;
import org.apache.commons.io.FilenameUtils;
import org.apache.commons.io.IOUtils;
import ucll.project.db.ConnectionPool;
import ucll.project.db.DbException;
import ucll.project.domain.avatar.AvatarDb;
import ucll.project.domain.user.Service;

import javax.swing.plaf.nimbus.State;
import java.io.InputStream;
import java.sql.*;
import java.util.*;


public class   CommendationDb implements CommendationRepository{

   private static int idCount;
   @Override
   public void createCommendation(Commendation commendation) {
      try (Connection conn = ConnectionPool.getConnection();
           PreparedStatement stmt = conn.prepareStatement("INSERT INTO commendation " +
                         "(id, description, to_employee, from_employee, tags) VALUES (?, ?, ?, ?, ?)",
                   Statement.RETURN_GENERATED_KEYS))
      {
         stmtSetCommendation(stmt, 1, commendation);
         if (stmt.executeUpdate() == 0) {
            throw new RuntimeException("Failed to create commendation");
         }

         try (ResultSet generatedKeys = stmt.getGeneratedKeys()) {
            generatedKeys.next();
            commendation.setId();
         }
      } catch (SQLException e) {
         throw new RuntimeException(e);
      }
   }

   public static int getIdCount() {
      try (Connection conn = ConnectionPool.getConnection();
           PreparedStatement stmt = conn.prepareStatement("SELECT max(id) FROM commendation"))
      {
         ResultSet rs = stmt.executeQuery();
         if (rs.next()) {
            idCount = rs.getInt(1);
         }
         return idCount;
      } catch (SQLException e) {
         e.printStackTrace();
      }
      return 69;
   }
   @Override
   public Commendation get(int commendationId) {
//      try (Connection conn = ConnectionPool.getConnection();
//           PreparedStatement stmt = conn.prepareStatement("SELECT * FROM commendation WHERE id = ?"))
//      {
//         stmt.setInt(1, commendationId);
//         try (ResultSet rs = stmt.executeQuery()) {
//            if (rs.next()) {
//               return commendationFromResult(rs);
//            }
//            return null;
//         }
//      } catch (SQLException e) {
//         throw new RuntimeException(e);
//      }
      return null;
   }

   @Override
   public List<Commendation> getAll() {
//      try (Connection conn = ConnectionPool.getConnection();
//           Statement stmt = conn.createStatement();
//           ResultSet rs = stmt.executeQuery("SELECT * FROM commendation"))
//      {
//         List<Commendation> commendations = new ArrayList<>();
//         while (rs.next()) {
//            commendations.add(commendationFromResult(rs));
//         }
//         return commendations;
//      } catch (SQLException e) {
//         throw new RuntimeException(e);
//      }
      return null;
   }

   @Override
   public List<History> getHistory() {
      try (Connection conn = ConnectionPool.getConnection();
           Statement stmt = conn.createStatement();
           ResultSet rs = stmt.executeQuery("select em.firstname as to_employee, e.firstname as from_employee, c.description, c.tags, av.image_content as imageContentTo, av.image as imageNameTo, ava.image_content as imageContentFrom, ava.image as imageNameFrom " +
                  "from commendation c " +
                  "left outer join employee e on c.to_employee = e.id " +
                  "left outer join employee em on c.from_employee = em.id "+
                   "left outer join avatar av on c.to_employee = av.of_employee "+
                   "left outer join avatar ava on c.from_employee = ava.of_employee "+
                   "order by c.id desc"))
      {
         List<History> history = new ArrayList<>();
         while (rs.next()) {
            history.add(historyFromResult(rs));
         }
         return history;
      } catch (SQLException e) {
         throw new RuntimeException(e);
      }
   }

   @Override
   public List<History> getHistoryFrom(String toEmployee) {
      try (Connection conn = ConnectionPool.getConnection();
           Statement stmt = conn.createStatement();
           ResultSet rs = stmt.executeQuery("select em.firstname as to_employee, e.firstname as from_employee, c.description, c.tags " +
                   "from commendation c " +
                   "left outer join employee e on c.to_employee = e.id " +
                   "left outer join employee em on c.from_employee = em.id" +
                   " order by c.id desc")) {
         List<History> given = new ArrayList<>();
         while (rs.next()) {
            fromResult(rs, toEmployee, given);
         }
         return given;
      } catch (SQLException e) {
         throw new RuntimeException(e);
      }
   }

   public List<History> getHistoryTag(Tag tag) {
      try (Connection conn = ConnectionPool.getConnection();
           PreparedStatement stmt = conn.prepareStatement("select em.firstname as to_employee, e.firstname as from_employee, c.description, c.tags, av.image_content as imageContentTo, av.image as imageNameTo, ava.image_content as imageContentFrom, ava.image as imageNameFrom " +
                   "from commendation c " +
                  "left outer join employee e on c.to_employee = e.id " +
                  "left outer join employee em on c.from_employee = em.id " +
                   "left outer join avatar av on c.to_employee = av.of_employee "+
                   "left outer join avatar ava on c.from_employee = ava.of_employee "+
                   "where c.tags like ? ESCAPE '!'" +
                  " order by c.id desc"))
      {
         stmt.setString(1, "%" + tag.getTag().toUpperCase() + "%");
         System.out.println(tag.getTag().toUpperCase());
         ResultSet rs = stmt.executeQuery();
         List<History> history = new ArrayList<>();
         while (rs.next()) {
            history.add(historyFromResult(rs));
         }
         return history;
      } catch (SQLException e) {
         throw new RuntimeException(e);
      }
   }

   private static void fromResult(ResultSet rs, String toEmployee, List<History> given) throws SQLException {
      History history = new History();
      if (rs.getString("to_employee").equals(toEmployee)) {
         history.setFromUser(rs.getString("to_employee"));
         history.setToUser(rs.getString("from_employee"));
         history.setDescription(rs.getString("description"));
         history.addTags(getTags(rs));
         given.add(history);
      }
   }

   @Override
   public List<History> getHistoryTo(String byEmployee) {
      try (Connection conn = ConnectionPool.getConnection();
           Statement stmt = conn.createStatement();
           ResultSet rs = stmt.executeQuery("select em.firstname as to_employee, e.firstname as from_employee, c.description, c.tags " +
                   "from commendation c " +
                   "left outer join employee e on c.to_employee = e.id " +
                   "left outer join employee em on c.from_employee = em.id" +
                   " order by c.id desc")) {
         List<History> received = new ArrayList<>();
         while (rs.next()) {
            toResult(rs, byEmployee, received);
         }
         return received;
      } catch (SQLException e) {
         throw new RuntimeException(e);
      }
   }

   private static void toResult(ResultSet rs, String byEmployee, List<History> received) throws SQLException {
      History history = new History();
      if (rs.getString("from_employee").equals(byEmployee)) {
         history.setFromUser(rs.getString("to_employee"));
         history.setToUser(rs.getString("from_employee"));
         history.setDescription(rs.getString("description"));
         history.addTags(getTags(rs));
         received.add(history);
      }
   }


   private static History historyFromResult(ResultSet rs) throws SQLException{
      History history = new History();
      history.setFromUser(rs.getString("to_employee"));
      history.setToUser(rs.getString("from_employee"));
      history.setDescription(rs.getString("description"));
      history.addTags(getTags(rs));

      // TODO LISA get images to add to history set
      Map<String, InputStream> imgFrom = new HashMap<>();
      Map<String, InputStream> imgTo = new HashMap<>();

      String filenameFrom = rs.getString("imageNameFrom");
      InputStream fileContentFrom = rs.getBinaryStream("imageContentFrom");
      imgFrom.put(filenameFrom, fileContentFrom);

      String filenameTo = rs.getString("imageNameTo");
      InputStream fileContentTo = rs.getBinaryStream("imageContentTo");
      imgTo.put(filenameTo, fileContentTo);

      String imageStringFrom = mapToStringImageMagic(imgFrom).get(0);
      history.setImageFromUser(imageStringFrom);

      String imageStringTo = mapToStringImageMagic(imgTo).get(0);
      history.setImageToUser(imageStringTo);

      return history;
   }

   private static List<String> mapToStringImageMagic(Map<String, InputStream> theMap){
      Map<String, InputStream> imgs = theMap;
      List<String> imgBase64 = new ArrayList<>();

      try {
         for (Map.Entry<String, InputStream> entry : imgs.entrySet()) {
            String extension = FilenameUtils.getExtension(entry.getKey());
            byte[] encoded = Base64.getEncoder().encode(IOUtils.toByteArray(entry.getValue()));
            imgBase64.add("data:image/" + extension + ";base64, " + new String(encoded));
         }
      } catch (Exception e) {
         System.out.println(e.getMessage());
      }
      System.out.println(imgBase64);
      return imgBase64;
   }


   private static ArrayList<Tag> getTags(ResultSet rs) throws SQLException {
      String tags = rs.getString("tags");
      tags = tags.replaceAll("\\[*\\]*", "");
      String[] foo = tags.split(", ");
      ArrayList<Tag> tag = new ArrayList<>();
      for (int i = 0; i < foo.length; i++) {
         tag.add(Tag.valueOf(foo[i]));
      }
      return tag;
   }

   private static Commendation commendationFromResult(ResultSet rs) throws SQLException{
//      Commendation commendation = new Commendation();
//      commendation.setId();
//      commendation.setDescription(rs.getString("description"));
//      commendation.setFromEmployee(rs.getInt("from_employee"));
//      commendation.setToEmployee(rs.getInt("to_employee"));
//      List<String> tags = new ArrayList<>();
//
//      for (int i = 0; i < 4; i++) {
//         tags.add(rs.getString("tag"));
//      }
//      commendation.setTag1(tags.get(0));
//
      return null;
   }


   private static int stmtSetCommendation(PreparedStatement stmt, int i, Commendation commendation) throws SQLException {
      stmt.setInt(i++, commendation.getId());
      stmt.setString(i++, commendation.getDescription());
      stmt.setInt(i++, commendation.getToEmployee());
      stmt.setInt(i++, commendation.getFromEmployee());
      stmt.setString(i++, commendation.getTags().toString());
      return i;
   }
}


