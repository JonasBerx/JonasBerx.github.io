package ucll.project.domain.avatar;

import ucll.project.domain.commendation.Tag;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

public class Avatar {
    private int id;
    private int ofEmployee;
    private InputStream content;
    private String imageName;

    public Avatar(){}

    public Avatar(int id, int ofEmployee, InputStream content, String imageName) {
        this.id = id;
        this.ofEmployee = ofEmployee;
        this.content = content;
        this.imageName = imageName;
    }

    public int getId() {
        return id;
    }

    public int getOfEmployee() {
        return ofEmployee;
    }

    public InputStream getContent() {
        return content;
    }

    public String getImageName() {
        return imageName;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setOfEmployee(int ofEmployee) {
        this.ofEmployee = ofEmployee;
    }

    public void setContent(InputStream content) {
        this.content = content;
    }

    public void setImageName(String imageName) {
        this.imageName = imageName;
    }
}
