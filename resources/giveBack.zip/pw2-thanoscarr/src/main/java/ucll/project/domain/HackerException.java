package ucll.project.domain;

public class HackerException extends Exception {
    private static final long serialVersionUID = 1L;

    public HackerException() {
        super();
    }

    public HackerException(String message, Throwable exception) {
        super(message, exception);
    }

    public HackerException(String message) {
        super(message);
    }

    public HackerException(Throwable exception) {
        super(exception);
    }
}
