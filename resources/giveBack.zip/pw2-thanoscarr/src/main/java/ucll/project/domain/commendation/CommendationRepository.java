package ucll.project.domain.commendation;

import java.util.List;

public interface CommendationRepository {
   void createCommendation(Commendation commendation);
   Commendation get(int commendationId);
   List<Commendation> getAll();
   List<History> getHistory();

   /**
    * Gets the History of a person's given commendations
    * @param toEmployee the name of the user that gave the commendations
    */

   List<History> getHistoryFrom(String toEmployee);


   /**
    * Gets the history of a person's received commendations
    * @param toEmployee the name of the user that received the commendations.
    *                   this is the person that is currently logged in.
    */
   List<History> getHistoryTo(String toEmployee);
}
