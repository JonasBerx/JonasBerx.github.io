package ucll.project.domain.user;

import ucll.project.domain.commendation.Commendation;

import javax.activation.DataHandler;
import javax.activation.DataSource;
import javax.activation.FileDataSource;
import javax.mail.*;
import javax.mail.internet.*;
import javax.mail.Authenticator;
import javax.mail.PasswordAuthentication;

import java.util.List;
import java.util.Properties;


public class Mail {

    private static final String SMTP_HOST_NAME = "smtp.gmail.com";
    private static final String SMTP_AUTH_USER = "projectweekG12@gmail.com";
    private static final String SMTP_AUTH_PWD  = "IpsosAdmin2020";


    public static void send(String receiver, String StringMessage) throws Exception{
        //mail send
        Properties props = new Properties();
        props.put("mail.smtp.host", SMTP_HOST_NAME);
        props.put("mail.smtp.port", "587");
        props.put("mail.smtp.auth", "true");
        props.put("mail.smtp.starttls.enable", "true");
        props.put("mail.transport.protocol", "smtp");

        Authenticator auth = new SMTPAuthenticator();
//        Session mailSession = Session.getDefaultInstance(props, auth);

        Session mailSession = Session.getInstance(props, new javax.mail.Authenticator() {
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication(SMTP_AUTH_USER, SMTP_AUTH_PWD);
            }
        });
        // uncomment for debugging infos to stdout
        // mailSession.setDebug(true);
        Transport transport = mailSession.getTransport();

        MimeMessage message = new MimeMessage(mailSession);
        BodyPart messageBodyPart = new MimeBodyPart();
//        DataSource fds = new FileDataSource(
//                "https://behaviour-driven-design.projectweek.be/static/imgs/star-small.png");

//        messageBodyPart.setDataHandler(new DataHandler(fds));
        messageBodyPart.setHeader("Content-ID", "<star>");

        message.setSubject("Give Back!");
        message.setContent(StringMessage,"text/html");
        message.setFrom(new InternetAddress(SMTP_AUTH_USER));
        message.addRecipient(Message.RecipientType.TO,
                new InternetAddress(receiver));

        transport.connect();
        transport.sendMessage(message,
                message.getRecipients(Message.RecipientType.TO));
        transport.close();
    }

    public static void sendToManager(String from, String to, Commendation c) throws MessagingException {
        List<String> managers = UserRepositoryDb.getManagers();
        //mail send
        Properties props = new Properties();
        props.put("mail.smtp.host", SMTP_HOST_NAME);
        props.put("mail.smtp.port", "587");
        props.put("mail.smtp.auth", "true");
        props.put("mail.smtp.starttls.enable", "true");
        props.put("mail.transport.protocol", "smtp");

        String StringMessage = "\n"+from + " has given back to " + to +"!\n" + to +" received a commendation with the tags:" + c.getTags() + ".\n";

        Authenticator auth = new SMTPAuthenticator();
        Session mailSession = Session.getDefaultInstance(props, auth);
        // uncomment for debugging infos to stdout
        // mailSession.setDebug(true);
        Transport transport = mailSession.getTransport();

        MimeMessage message = new MimeMessage(mailSession);
        BodyPart messageBodyPart = new MimeBodyPart();
//        DataSource fds = new FileDataSource(
//                "https://behaviour-driven-design.projectweek.be/static/imgs/star-small.png");

//        messageBodyPart.setDataHandler(new DataHandler(fds));
        messageBodyPart.setHeader("Content-ID", "<star>");

        message.setSubject(c.getFromEmployee() +" has given back!");
        message.setContent(StringMessage,"text/html");
        message.setFrom(new InternetAddress(SMTP_AUTH_USER));
        //This is how it will work later!
//            for (String manager : managers) {
//                message.addRecipient(Message.RecipientType.TO,
//                        new InternetAddress(manager));
//            }
        message.addRecipient(Message.RecipientType.TO,
                new InternetAddress("ltias.business@gmail.com"));

        transport.connect();
        transport.sendMessage(message,
                message.getRecipients(Message.RecipientType.TO));
        transport.close();
    }

    private static class SMTPAuthenticator extends javax.mail.Authenticator {
        public PasswordAuthentication getPasswordAuthentication() {
            String username = SMTP_AUTH_USER;
            String password = SMTP_AUTH_PWD;
            return new PasswordAuthentication(username, password);
        }
    }
}