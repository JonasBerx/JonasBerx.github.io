package ucll.project.domain.commendation;

import ucll.project.domain.HackerException;
import ucll.project.domain.user.User;

import javax.servlet.http.HttpServletRequest;
import java.util.ArrayList;

public class CommendationFactory {

public Commendation create(HttpServletRequest request, ArrayList<String> fouten, User id){
   Commendation p = new Commendation();
   processId(p,request,fouten);
   processDescription(p,request,fouten);
   processToEmployee(p,request,fouten, id.getUserId());
   processFromEmployee(p, request,fouten);
   processTags(p,request,fouten);
   return p;
}

private void processId(Commendation p, HttpServletRequest request, ArrayList<String> fouten){
   try{
      p.setId();
   } catch (IllegalArgumentException e){
      fouten.add(e.getMessage());
   }
}

private void processDescription(Commendation p, HttpServletRequest request, ArrayList<String> fouten){
   try{
      p.setDescription(request.getParameter("description"));
   } catch (IllegalArgumentException e){
      fouten.add(e.getMessage());
   }
}

private void processToEmployee(Commendation p, HttpServletRequest request, ArrayList<String> fouten, int id){
   try{
      p.setToEmployee(id);
   } catch (IllegalArgumentException e){
      fouten.add(e.getMessage());
   }
}

private void processFromEmployee(Commendation p, HttpServletRequest request, ArrayList<String> fouten){
   try{
      p.setFromEmployee(((User)request.getSession().getAttribute("user")).getUserId());
   } catch (IllegalArgumentException e){
      fouten.add(e.getMessage());
   }
}

private void processTags(Commendation p, HttpServletRequest request, ArrayList<String> fouten){
   try{
      if(request.getParameter("tag1")!= null){
         p.addTag(Tag.valueOf(request.getParameter("tag1")));
      }
      if(request.getParameter("tag2")!= null){
         System.out.println(request.getParameter("tag2"));
         p.addTag(Tag.valueOf(request.getParameter("tag2")));
      }
      if(request.getParameter("tag3")!= null){
         p.addTag(Tag.valueOf(request.getParameter("tag3")));
      }
      if(request.getParameter("tag4")!= null){
         p.addTag(Tag.valueOf(request.getParameter("tag4")));
      }
   } catch (IllegalArgumentException e){
      fouten.add(e.getMessage());
   }
   System.out.println(p.getTags());
}

}
