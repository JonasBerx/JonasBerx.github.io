package ucll.project.ui.controller;

import ucll.project.domain.commendation.History;
import ucll.project.domain.user.Service;
import ucll.project.domain.user.User;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

public class Index extends RequestHandler {
    public Index(String command, Service userService) {
        super(command, userService);
    }

    @Override
    public void handleRequest(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        if (request.getSession().getAttribute("user") == null){
            request.getRequestDispatcher("login.jsp").forward(request, response);
        } else {
            request.setAttribute("history", this.getUserService().getHistory());

            User userUserGivingStar = (User) request.getSession().getAttribute("user");
            String userGivingStar = userUserGivingStar.getFirstName();
            int countStarsFromUser = 0;
            List<History> usersHistory = this.getUserService().getHistory();
            for (History history : usersHistory){
                if(history.getFromUser().equals(userGivingStar)){
                    countStarsFromUser++;
                }
            }
            userUserGivingStar.setStars(3 - countStarsFromUser);

            request.setAttribute("remainingstars", userUserGivingStar.getStars());

            request.getRequestDispatcher("index.jsp").forward(request, response);
        }

    }

}
