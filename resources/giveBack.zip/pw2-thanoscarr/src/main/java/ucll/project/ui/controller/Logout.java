package ucll.project.ui.controller;

import ucll.project.domain.user.Service;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

public class Logout extends RequestHandler {

   public Logout(String command, Service userService){super(command, userService);}

   @Override
   public void handleRequest(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
      request.getSession().invalidate();
      request.getRequestDispatcher("login.jsp").forward(request,response);
   }
}
