package ucll.project.domain.user;

import java.util.List;

public interface UserRepository {

    // CREATE
    void createUser(User user, String password);

    // READ ONE
    User get(int userId);

    // READ ALL
    List<User> getAll();

    User getUser(String email);

    // UPDATE
    void update(User user);

    // DELETE
    void delete(User user);

    void addUser(User user);


    List<String> getManager();
}
