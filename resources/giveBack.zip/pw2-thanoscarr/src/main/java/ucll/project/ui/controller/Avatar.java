package ucll.project.ui.controller;

//import org.graalvm.compiler.debug.DebugContext;
import org.apache.commons.io.FilenameUtils;
import org.apache.commons.io.IOUtils;
import ucll.project.db.ConnectionPool;
import ucll.project.domain.commendation.History;
import ucll.project.domain.user.Gender;
import ucll.project.domain.user.User;
import ucll.project.domain.user.Service;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;
import java.io.*;
import java.net.URL;
import java.nio.channels.FileLockInterruptionException;
import java.nio.file.Paths;
import java.sql.*;
import java.util.*;
import java.util.logging.Level;

import static ucll.project.ui.controller.Controller.LOGGER;

public class Avatar extends RequestHandler {
    private static int idCounter = 0;

    public static synchronized int createId(){return idCounter++;}

    public Avatar(String command, Service userService) {
        super(command, userService);
    }

    @Override
    public void handleRequest(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // TODO Set attributes (In Avatar, Same as profile)
        // TODO Set attributes
        User user = (User) request.getSession().getAttribute("user");
        request.setAttribute("user", user);
        System.out.println(user);

        String email = user.getEmail();
        Gender gender = user.getGender();

        request.setAttribute("email", email);
        request.setAttribute("gender", gender);

        // Get selected avatar image
        Part filePart = request.getPart("file");
        String fileName = Paths.get(filePart.getSubmittedFileName()).getFileName().toString();
        InputStream fileContent = filePart.getInputStream();

        if (hasImage(user.getUserId())){
            // update
            updateToDatabase(fileName, fileContent, user.getUserId());
        }
        else{
            // create new
            uploadToDatabase(fileName, fileContent, user.getUserId());
        }

        // TODO get this stuff into index
        Map<String, InputStream> imgs = getImgByEmployeeId(user.getUserId());
        List<String> imgBase64 = new ArrayList<>();

        try {
            for (Map.Entry<String, InputStream> entry : imgs.entrySet()) {
                String extension = FilenameUtils.getExtension(entry.getKey());
                byte[] encoded = Base64.getEncoder().encode(IOUtils.toByteArray(entry.getValue()));
                imgBase64.add("data:image/" + extension + ";base64, " + new String(encoded));
            }
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
        System.out.println(imgBase64);
        request.setAttribute("imageUrlList", imgBase64);

        //TODO Add functionality to get commendations from database and add them to the list.
        List<History> historyGiven = getUserService().getHistoryFrom(user.getFirstName());
        List<History> historyReceived = getUserService().getHistoryBy(user.getFirstName());

        request.setAttribute("commendationsReceivedList", historyReceived);
        request.setAttribute("commendationsGivenList", historyGiven);


        request.getRequestDispatcher("profile.jsp").forward(request, response);
    }

    private boolean hasImage(int userId){
        String sql = "select count(*) from avatar where of_employee = ?";
        try ( Connection connection = ConnectionPool.getConnection()){
            PreparedStatement stmt = connection.prepareStatement(sql);
            stmt.setInt(1, userId);
            ResultSet resultSet = stmt.executeQuery();
            int amount = 0;
            while (resultSet.next()) {
                amount = resultSet.getInt("count");
            }
            if (amount == 0){
                return false;
            }else{
                return true;
            }
        } catch (Exception e) {
            System.out.println(e.getMessage());
            throw new IllegalArgumentException(e);
        }
    }



    private void uploadToDatabase(String fileName, InputStream fileContent, int userID) {
        String sql = "insert into avatar(image, image_content, of_employee) values (?,?,?)";
        try ( Connection connection = ConnectionPool.getConnection()){
            PreparedStatement stmt = connection.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
            System.out.println("Connected to the PostgreSQL server successfully.");
            stmt.setString(1, fileName);
            stmt.setBinaryStream(2, fileContent);
            stmt.setInt(3, userID);
            if (stmt.executeUpdate() == 0){
                throw new Exception("Failed to create avatar db item");
            }
            try (ResultSet generatedKeys = stmt.getGeneratedKeys()){
                generatedKeys.next();
            }
        } catch (Exception e) {
            System.out.println(e.getMessage());
            throw new IllegalArgumentException(e);
        }
    }

    private void updateToDatabase(String fileName, InputStream fileContent, int userID) {
        String sql = "delete from avatar where of_employee = ?";
        try ( Connection connection = ConnectionPool.getConnection()){
            PreparedStatement stmt = connection.prepareStatement(sql);
            stmt.setInt(1, userID);
            if (stmt.executeUpdate() == 0){
                throw new Exception("Failed to delete avatar db item");
            }
            uploadToDatabase(fileName,fileContent,userID);
        } catch (Exception e) {
            System.out.println(e.getMessage());
            throw new IllegalArgumentException(e);
        }

    }

    // show picture per user
    private Map<String, InputStream> getImgByEmployeeId(int employeeId) {
        Map<String, InputStream> imgs = new HashMap<>();

        String sql = "select image, image_content from avatar where of_employee = ?";
        //String sql = "select image, image_content from avatar";
        try ( Connection connection = ConnectionPool.getConnection()){
            PreparedStatement stmt = connection.prepareStatement(sql);
            stmt.setInt(1, employeeId);
            ResultSet resultSet = stmt.executeQuery();

            while (resultSet.next()) {
                String filename = resultSet.getString("image");
                InputStream fileContent = resultSet.getBinaryStream("image_content");
                imgs.put(filename, fileContent);
            }
        } catch (Exception e) {
            System.out.println(e.getMessage());
            throw new IllegalArgumentException(e);
        }
        return imgs;
    }
}

