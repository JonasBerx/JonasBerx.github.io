package ucll.project.ui.controller;

import net.bytebuddy.TypeCache;
import ucll.project.domain.commendation.Commendation;
import ucll.project.domain.commendation.History;
import ucll.project.domain.commendation.Tag;
import ucll.project.domain.user.Service;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class SortTag extends RequestHandler {

   public SortTag(String command, Service userService){
      super(command, userService);
   }

   @Override
   public void handleRequest(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
      if (request.getSession().getAttribute("user") == null){
         request.getRequestDispatcher("login.jsp").forward(request, response);
      } else {
         if(request.getParameter("tag") != null){
            Tag tag = Tag.valueOf(request.getParameter("tag"));
            request.setAttribute("history", this.getUserService().getHistoryTag(tag));
            request.getRequestDispatcher("index.jsp").forward(request, response);
         } else {
            response.sendRedirect("Controller?command=Index");
         }

      }
   }
}
