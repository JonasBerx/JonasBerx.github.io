package ucll.project.domain.user;

import ucll.project.db.ConnectionPool;
import ucll.project.domain.commendation.Tag;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class UserRepositoryDb implements UserRepository {

    @Override
    public void createUser(User user, String password) {
        try (Connection conn = ConnectionPool.getConnection();
             PreparedStatement stmt = conn.prepareStatement("INSERT INTO employee " +

                     "(username, firstname, lastname, email, gender, role, password, remaining) VALUES (?, ?, ?, ?, ?, ?, ?, ?)",

                     Statement.RETURN_GENERATED_KEYS))
        {
            user.hashAndSetPassword(password);
            stmtSetUser(stmt, 1, user);
            if (stmt.executeUpdate() == 0) {
                throw new RuntimeException("Failed to create user");
            }

            try (ResultSet generatedKeys = stmt.getGeneratedKeys()) {
                generatedKeys.next();
                user.setUserId(generatedKeys.getInt(1));
            }
            //create avatar for user
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public User get(int userId) {
        try (Connection conn = ConnectionPool.getConnection();
             PreparedStatement stmt = conn.prepareStatement("SELECT * FROM \"employee\" WHERE id = ?"))
        {
            stmt.setInt(1, userId);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return userFromResult(rs);
                }
                return null;
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public List<User> getAll() {
        try (Connection conn = ConnectionPool.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT * FROM employee"))
        {
            List<User> users = new ArrayList<>();
            while (rs.next()) {
                users.add(userFromResult(rs));
            }
            return users;
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    //username for form
    @Override
    public User getUser(String email){
        User user= new User();
        try (Connection connection = ConnectionPool.getConnection();
             PreparedStatement statement = connection.prepareStatement("SELECT * from employee where email = ?")
        ){
            statement.setString(1, email);
            ResultSet resultSet = statement.executeQuery();
            resultSet.next();
            user = userFromResult(resultSet);

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return user;
    }

//    @Override
//    public User loginUser(String username, String password) throws InvalidLogin {
//        try (Connection conn = ConnectionPool.getConnection();
//             PreparedStatement stmt = conn.prepareStatement("SELECT * FROM employee WHERE email = ?"))
//        {
//            stmt.setString(1, username);
//            try (ResultSet rs = stmt.executeQuery()) {
//                if (!rs.next()) {
//                    throw new InvalidLogin("Invalid email");
//                }
//
//                User user = userFromResult(rs);
//                if (!user.isValidPassword(password)) {
//                    throw new InvalidLogin("Invalid password");
//                }
//
//                return user;
//            }
//        } catch (SQLException e) {
//            throw new RuntimeException(e);
//        }
//    }

    @Override
    public void update(User user) {
        try (Connection conn = ConnectionPool.getConnection();
             PreparedStatement stmt = conn.prepareStatement("UPDATE employee SET " +
                     "username = ?, firstname = ?, lastname = ?, email = ?, gender = ?, role = ?, password = ?, remaining = ? " +
                     "WHERE id = ? "))
        {
            int i = stmtSetUser(stmt, 1, user);
            stmt.setInt(i, user.getUserId());
            stmt.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public void delete(User user) {
        try (Connection conn = ConnectionPool.getConnection();
             PreparedStatement stmt = conn.prepareStatement("DELETE FROM employee WHERE id = ?"))
        {
            stmt.setInt(1, user.getUserId());
            stmt.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public void addUser(User user) {
        try (Connection conn = ConnectionPool.getConnection();
             PreparedStatement stmt = conn.prepareStatement("Insert into employee VALUES(?,?,?,?,?,?,?,?)"))
        {
            stmt.setInt(1,user.getUserId());
            stmt.setString(2,user.getFirstName());
            stmt.setString(3,user.getLastName());
            stmt.setString(4,user.getEmail());
            stmt.setString(5,String.valueOf(user.getGender()));
            stmt.setString(6,String.valueOf(user.getRole()));
            stmt.setString(7,user.getHashedPassword());
            stmt.setInt(8,user.getStars());
            stmt.execute();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public List<String> getManager() {
        return getManagers();
    }


    public static List<String> getManagers() {
        List<String> managers = new ArrayList<>();
        try (Connection conn = ConnectionPool.getConnection();
             PreparedStatement stmt = conn.prepareStatement("select email from employee where role ilike '%MANAGER%'"))
        {
            ResultSet resultSet = stmt.executeQuery();
            resultSet.next();
            while (resultSet.next()) {
                managers.add(getTheManagers(resultSet));
            }


        } catch (SQLException e) {
            e.printStackTrace();
        }
        return managers;
    }

    private static String getTheManagers(ResultSet resultSet) throws SQLException {
        String email = "";
        email = resultSet.getString("email");
        System.out.println(email);
        return email;
    }

    private static User userFromResult(ResultSet rs) throws SQLException {
        User user = new User();
        user.setUserId(rs.getInt("id"));
        user.setFirstName(rs.getString("firstname"));
        user.setLastName(rs.getString("lastname"));
        user.setEmail(rs.getString("email"));
        user.setGender(Gender.valueOf(rs.getString("gender")));
        user.setRoles(getRoles(rs));
        user.setHashedPassword(rs.getString("password"));
        user.setStars(rs.getInt("remaining"));
        return user;
    }
    private static int stmtSetUser(PreparedStatement stmt, int i, User user) throws SQLException {
        stmt.setString(i++, user.getFirstName());
        stmt.setString(i++, user.getLastName());
        stmt.setString(i++, user.getEmail());
        stmt.setString(i++, user.getGender().toString());
        stmt.setString(i++, user.getRole().toString());
        stmt.setString(i++, user.getHashedPassword());
        stmt.setInt(i++,3);
        return i;
    }

    private static ArrayList<Role> getRoles(ResultSet rs) throws SQLException {
        String roles = rs.getString("role");
        roles = roles.replaceAll("\\[*\\]*", "");
        String[] foo = roles.split(", ");
        ArrayList<Role> tag = new ArrayList<>();
        for (int i = 0; i < foo.length; i++) {
            tag.add(Role.valueOf(foo[i]));
        }
        return tag;
    }
}