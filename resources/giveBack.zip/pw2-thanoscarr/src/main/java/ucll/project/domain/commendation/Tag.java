package ucll.project.domain.commendation;

public enum Tag {
    INTEGRITY("Integrity"),
    CURIOSITY("Curiosity"),
    COLLABORATION("Collaboration"),
    CLIENTFIRST("Clientfirst"),
    ENTREPRENEURSHIP("Entrepeneurship"),
    MOVEFASTER("Movefaster"),
    ACTSMARTER("Actsmarter"),
    GOFURTHER("Gofurther"),
    BESURE("Besure"),
    TEAMSPIRIT("Teamspirit"),
    OFFICESPIRIT("Officespirit");


    private String tag;

    Tag(String tag) {
        this.tag = tag;
    }

    public void setTag(String tag) {
        this.tag = tag;
    }

    public String getTag() {
        return this.tag;
    }
}
