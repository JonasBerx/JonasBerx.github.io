package ucll.project.domain.user;

import ucll.project.db.DbException;
import ucll.project.domain.DomainException;
import ucll.project.domain.commendation.Tag;

import javax.servlet.http.HttpServletRequest;
import java.security.SecureRandom;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class UserFactory {

   public User create(ResultSet result){
      User p = new User();
      try {
         p.setUserId(result.getInt("userid"));
         p.setEmail(result.getString("email"));
         p.setFirstName(result.getString("firstname"));
         p.setLastName(result.getString("lastname"));
         p.hashAndSetPassword(result.getString("password"));
         p.setRole(Role.valueOf(result.getString("role")));
         p.setGender(Gender.valueOf(result.getString("gender")));
         p.setStars(3);
      } catch (SQLException | NumberFormatException e) {
         throw new DbException(e.getMessage());
      } catch (NullPointerException e){
         throw new DbException(e.getMessage() + "sf ");
      }
      return p;
   }

   public User create(HttpServletRequest request, ArrayList<String> fouten){
      User p = new User();
      processId(p,request,fouten);
      processFirstName(p,request,fouten);
      processLastName(p,request,fouten);
      processEmail(p,request,fouten);
      processPassWord(p,request,fouten);
      processRole(p,request,fouten);
      processGender(p,request,fouten);
      p.setStars(3);
      return p;
   }

   private void processRole(User p, HttpServletRequest request, ArrayList<String> fouten) {
      try{
         Boolean foo = false;
         if(request.getParameter("role1")!= null){
            foo = true;
            p.setRole(Role.valueOf(request.getParameter("role1")));
         }
         if(request.getParameter("role2")!= null){
            foo = true;
            p.setRole(Role.valueOf(request.getParameter("role2")));
         }
         if(request.getParameter("role3")!= null){
            foo = true;
            p.setRole(Role.valueOf(request.getParameter("role3")));
         }
         if(request.getParameter("role4")!= null){
            foo = true;
            p.setRole(Role.valueOf(request.getParameter("role4")));
         }
         if (!foo){
            fouten.add("No role selected");
         }
      }catch (NumberFormatException e){
         fouten.add("This person role is invalid");
      }catch (IllegalArgumentException e){
         fouten.add(e.getMessage());
      }
   }

   private void processId(User p, HttpServletRequest request, ArrayList<String> fouten) {
      try{
         p.setUserId(Integer.parseInt(request.getParameter("userid")));
      }catch (NumberFormatException e){
         fouten.add("This person ID isn't a number");
      }catch (IllegalArgumentException e){
         fouten.add(e.getMessage());
      }
   }

   private void processPassWord(User p, HttpServletRequest request, ArrayList<String> fouten) {
      try{
         p.hashAndSetPassword(request.getParameter("password"));
      }catch (NullPointerException | DomainException | IllegalArgumentException e){
         fouten.add(e.getMessage());
      }
   }

   private void processEmail(User p, HttpServletRequest request, ArrayList<String> fouten) {
      try{
         p.setEmail(request.getParameter("email"));
      }catch (NullPointerException | DomainException | IllegalArgumentException e){
         fouten.add(e.getMessage());
      }
   }

   private void processFirstName(User p, HttpServletRequest request, ArrayList<String> fouten) {
      try{
         p.setFirstName(request.getParameter("firstname"));
      }catch (NullPointerException | DomainException | IllegalArgumentException e){
         fouten.add(e.getMessage());
      }
   }

   private void processLastName(User p, HttpServletRequest request, ArrayList<String> fouten) {
      try{
         p.setLastName(request.getParameter("lastname"));
      }catch (NullPointerException | DomainException | IllegalArgumentException e){
         fouten.add(e.getMessage());
      }
   }

   public void processGender(User p, HttpServletRequest request, ArrayList<String> fouten){
      try{
         if(request.getParameter("gender") != null) {
            p.setGender(Gender.valueOf(request.getParameter("gender")));
         } else {
            fouten.add("This persons gender is not selected");
         }
      }catch (NumberFormatException e){
         fouten.add("This person gender is invalid");
      }catch (NullPointerException | IllegalArgumentException e){
         fouten.add(e.getMessage());
      }
   }

}
