package ucll.project.ui.controller;

import ucll.project.db.DbException;
import ucll.project.domain.user.Service;
import ucll.project.domain.user.User;
import ucll.project.domain.user.UserFactory;

import javax.mail.MessagingException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.ArrayList;

public class CreateUser extends RequestHandler{

   public CreateUser(String command, Service userService){super(command, userService);}

   @Override
   public void handleRequest(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
      if (!((User) request.getSession().getAttribute("user")).getIsAdmin()){
         request.getRequestDispatcher("hackerError.jsp").forward(request,response);
      }
      if (request.getParameter("firstname").contains("<script") || request.getParameter("lastname").contains("<script")){
         request.getRequestDispatcher("hackerError.jsp").forward(request, response);
      }else{
         ArrayList<String> fouten = new ArrayList<>();
         try {

            UserFactory factory = new UserFactory();
            User p = factory.create(request, fouten);

            getUserService().addUser(p);
            String message = "Hi " + p.getFirstName() + ",\nWelcome to GiveBack!\nBelow you will find your login credentials.\nEmail: " + p.getEmail() + "\nPassword: Ipsos2020\n\n See you soon!";
            getUserService().sendMail(p.getEmail(), message);
         } catch (DbException e) {
            e.printStackTrace();
            fouten.add(e.getMessage());
         } catch (Exception e) {
            e.printStackTrace();
         }
         if(fouten.size() == 0){
            response.sendRedirect("Controller?command=Users");
         }else{
            request.setAttribute("error",fouten);
            request.getRequestDispatcher("Controller?command=RedirectCreate").forward(request,response);
         }
      }
   }
}
