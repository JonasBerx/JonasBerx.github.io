package ucll.project.ui.controller;

import ucll.project.domain.user.Service;
import ucll.project.domain.user.User;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.util.ArrayList;

public class Login extends RequestHandler {

   public Login(String command, Service userService){super(command, userService);}

   @Override
   public void handleRequest(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
      try{
         User u = getUserService().getUser(request.getParameter("username"));
         if(u != null && u.isValidPassword(request.getParameter("password"))){
            HttpSession s = request.getSession();
            s.setAttribute("user", u);
            response.sendRedirect("Controller?command=Index");
         }else{
            ArrayList<String> fouten = new ArrayList<>();
            fouten.add("The emailadress and/or password is wrong");
            request.setAttribute("fouten", fouten);
            request.getRequestDispatcher("login.jsp").forward(request, response);
         }
      }catch(Exception e){
         ArrayList<String> fouten = new ArrayList<>();
         fouten.add("The emailadress and/or password is wrong");
         request.setAttribute("fouten",fouten);
         request.getRequestDispatcher("login.jsp").forward(request,response);
      }
   }
}
