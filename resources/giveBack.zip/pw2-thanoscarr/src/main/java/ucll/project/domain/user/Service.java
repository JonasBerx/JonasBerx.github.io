package ucll.project.domain.user;

import ucll.project.domain.commendation.Commendation;
import ucll.project.domain.commendation.CommendationDb;
import ucll.project.domain.commendation.History;
import ucll.project.domain.commendation.Tag;

import javax.mail.MessagingException;
import java.util.List;

public class Service {
    private UserRepository userRepo;
    private CommendationDb commendationDb;
    private Mail mailSender;

    public Service(){
        userRepo = new UserRepositoryDb();
        commendationDb = new CommendationDb();
    }

    public List<String> getManagers() {
        return userRepo.getManager();
    }

    public List<User> getUsers(){
        return userRepo.getAll();
    }

    public List<History> getHistory(){
        return commendationDb.getHistory();
    }

    public void sendMail(String dest,String message) throws Exception {
        Mail.send(dest,message);
    }

    public void sendToManager(String from, String to, Commendation c) throws MessagingException {
        Mail.sendToManager(from, to,c);
    }

    public List<History> getHistoryFrom(String employee) {
        return commendationDb.getHistoryFrom(employee);
    }
    public List<History> getHistoryBy(String employee) {
        return commendationDb.getHistoryTo(employee);
    }
    public List<History> getHistoryTag(Tag tag){return commendationDb.getHistoryTag(tag);}
    public User getUser(String email){return  userRepo.getUser(email);}

    public void addCommendation(Commendation commendation){
        commendationDb.createCommendation(commendation);
    }

    public void addUser(User user){userRepo.addUser(user);}

}
