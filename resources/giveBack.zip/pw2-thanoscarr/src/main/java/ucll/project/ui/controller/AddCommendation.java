package ucll.project.ui.controller;

import ucll.project.db.DbException;
import ucll.project.domain.HackerException;
import ucll.project.domain.commendation.*;
import ucll.project.domain.user.User;
import ucll.project.domain.user.Service;

import javax.mail.MessagingException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class AddCommendation extends RequestHandler{

    public AddCommendation(String command, Service service) {
        super(command, service);
    }

    @Override
    public void handleRequest(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {


        if (request.getSession().getAttribute("user") == null) {
            throw new IllegalArgumentException("rip");
        }
        if (request.getParameter("description").contains("<script")) {
            request.getRequestDispatcher("hackerError.jsp").forward(request, response);
        } else {
            CommendationFactory factory = new CommendationFactory();
            ArrayList<String> fouten = new ArrayList<>();

            Commendation c;
            System.out.println(request.getParameter("toEmployee"));
            System.out.println(getUserService().getUser(request.getParameter("toEmployee")).getFirstName());
            String to = getUserService().getUser(request.getParameter("toEmployee")).getFirstName();
            User u = (User) request.getSession().getAttribute("user");
            //check if star limit is reached
            String userGivingStar = u.getFirstName();
            int countStarsFromUser = 0;
            List<History> usersHistory = this.getUserService().getHistory();
            for (History history : usersHistory) {
                if (history.getFromUser().equals(userGivingStar)) {
                    countStarsFromUser++;
                }
            }
            if (u.getIsSuperUser()) {
                u.setStars(99);
            } else {
                u.setStars(3 - countStarsFromUser);
                System.out.println(countStarsFromUser);
            }

            request.setAttribute("stars", u.getStars());
            if (countStarsFromUser == 3) {
                fouten.add("You reached your limit for giving back this month.\nYou can give Kudo's again next month!:)");
                request.setAttribute("error", fouten);
                request.getRequestDispatcher("giveStar.jsp").forward(request, response);
            } else {

                c = factory.create(request, fouten, getUserService().getUser(request.getParameter("toEmployee")));
                u.setStars(u.getStars() - 1);

                System.out.println(u.getFirstName());
                String from = u.getFirstName();
                try {
                    getUserService().addCommendation(c);

                    getUserService().sendToManager(from, to, c);

                } catch (DbException e) {
                    fouten.add(e.getMessage());
                } catch (MessagingException e) {
                    e.printStackTrace();
                }
                if (fouten.size() == 0) {
                    response.sendRedirect("Controller?command=Index");
                } else {
                    request.setAttribute("error", fouten);
                    request.getRequestDispatcher("giveStar.jsp").forward(request, response);
                }
            }
        }

    }


}
