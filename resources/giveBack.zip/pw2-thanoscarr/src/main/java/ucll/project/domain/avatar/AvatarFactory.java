package ucll.project.domain.avatar;

import ucll.project.domain.commendation.Commendation;
import ucll.project.domain.commendation.Tag;
import ucll.project.domain.user.User;

import javax.servlet.http.HttpServletRequest;
import java.io.InputStream;
import java.util.ArrayList;

public class AvatarFactory {

    public Avatar create(HttpServletRequest request, ArrayList<String> fouten, String name, InputStream fileContent){
        Avatar a = new Avatar();
        processOfEmployee(a,request,fouten);
        processImageContent(a, request,fouten, fileContent);
        processImageName(a,request,fouten, name);
        return a;
    }

    private void processOfEmployee(Avatar a, HttpServletRequest request, ArrayList<String> fouten){
        try{
            a.setOfEmployee(((User)request.getSession().getAttribute("user")).getUserId());
        } catch (IllegalArgumentException e){
            fouten.add(e.getMessage());
        }
    }

    private void processImageContent(Avatar a, HttpServletRequest request, ArrayList<String> fouten, InputStream fileContent){
        try{
            a.setContent(fileContent);
        } catch (IllegalArgumentException e){
            fouten.add(e.getMessage());
        }
    }

    private void processImageName(Avatar a, HttpServletRequest request, ArrayList<String> fouten, String name){
        try{
            a.setImageName(name);
        } catch (IllegalArgumentException e){
            fouten.add(e.getMessage());
        }
    }


}
