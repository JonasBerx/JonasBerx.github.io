package ucll.project.domain.avatar;

import ucll.project.db.ConnectionPool;

import java.io.InputStream;
import java.sql.*;
import java.util.HashMap;
import java.util.Map;

public class AvatarDb implements AvatarRepository {

    @Override
    public void addAvatar(Avatar avatar) {
        String sql = "insert into avatar(image, image_content, of_employee) values (?,?,?)";
        try ( Connection connection = ConnectionPool.getConnection()){
            PreparedStatement stmt = connection.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
            System.out.println("Connected to the PostgreSQL server successfully.");
            stmt.setString(1, avatar.getImageName());
            stmt.setBinaryStream(2, avatar.getContent());
            stmt.setInt(3, avatar.getOfEmployee());
            if (stmt.executeUpdate() == 0){
                throw new Exception("Failed to create avatar db item");
            }
            try (ResultSet generatedKeys = stmt.getGeneratedKeys()){
                generatedKeys.next();
            }
        } catch (Exception e) {
            System.out.println(e.getMessage());
            throw new IllegalArgumentException(e);
        }
    }

    @Override
    public Avatar getById(int avatarId) {
        // not implemented
        return null;
    }

    @Override
    public Map<String, InputStream> getByEmployeeId(int employeeId) {
        Map<String, InputStream> imgs = new HashMap<>();

        String sql = "select image, image_content from avatar where of_employee = ?";
        //String sql = "select image, image_content from avatar";
        try ( Connection connection = ConnectionPool.getConnection()){
            PreparedStatement stmt = connection.prepareStatement(sql);
            stmt.setInt(1, employeeId);
            ResultSet resultSet = stmt.executeQuery();

            while (resultSet.next()) {
                String filename = resultSet.getString("image");
                InputStream fileContent = resultSet.getBinaryStream("image_content");
                imgs.put(filename, fileContent);
            }
        } catch (Exception e) {
            System.out.println(e.getMessage());
            throw new IllegalArgumentException(e);
        }
        return imgs;
    }

    @Override
    public Map<String, InputStream> getAll() {
        Map<String, InputStream> imgs = new HashMap<>();

        String sql = "select image, image_content from avatar";
        try ( Connection connection = ConnectionPool.getConnection()){
            PreparedStatement stmt = connection.prepareStatement(sql);
            ResultSet resultSet = stmt.executeQuery();

            while (resultSet.next()) {
                String filename = resultSet.getString("image");
                InputStream fileContent = resultSet.getBinaryStream("image_content");
                imgs.put(filename, fileContent);
            }
        } catch (Exception e) {
            System.out.println(e.getMessage());
            throw new IllegalArgumentException(e);
        }
        return imgs;
    }

    @Override
    public void update(Avatar avatar) {
        String sql = "delete from avatar where of_employee = ?";
        try ( Connection connection = ConnectionPool.getConnection()){
            PreparedStatement stmt = connection.prepareStatement(sql);
            stmt.setInt(1, avatar.getOfEmployee());
            if (stmt.executeUpdate() == 0){
                throw new Exception("Failed to delete avatar db item");
            }
            addAvatar(avatar);
        } catch (Exception e) {
            System.out.println(e.getMessage());
            throw new IllegalArgumentException(e);
        }
    }

    @Override
    public void delete(Avatar avatar) {
        String sql = "delete from avatar where of_employee = ?";
        try ( Connection connection = ConnectionPool.getConnection()){
            PreparedStatement stmt = connection.prepareStatement(sql);
            stmt.setInt(1, avatar.getOfEmployee());
            if (stmt.executeUpdate() == 0){
                throw new Exception("Failed to delete avatar db item");
            }
        } catch (Exception e) {
            System.out.println(e.getMessage());
            throw new IllegalArgumentException(e);
        }
    }
}
