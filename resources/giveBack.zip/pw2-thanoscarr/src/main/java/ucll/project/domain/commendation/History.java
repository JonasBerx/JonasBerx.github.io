package ucll.project.domain.commendation;

import io.cucumber.java.it.Ma;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class History {
   private String fromUser, toUser, description;
   private ArrayList<Tag> tags = new ArrayList<>();
   private String imageFromUser, imageToUser;

   public History(){
   }

   public History(String fromUser, String toUser, String description, ArrayList<Tag> tags, String imageFromUser, String imageToUser){
      this.fromUser = fromUser;
      this.toUser = toUser;
      this.description = description;
      this.tags = tags;
      this.imageToUser = imageToUser;
      this.imageFromUser = imageFromUser;
   }

   public String getFromUser() {
      return fromUser;
   }

   public String getToUser() {
      return toUser;
   }

   public String getDescription() {
      return description;
   }

   public String getImageFromUser(){
      return  imageFromUser; }

   public String getImageToUser(){
      return  imageToUser; }

   public List<Tag> getTags() {
      return tags;
   }

   public String getTagsString(){
      String out = "";
      for (Tag t: tags) {
         out += t.toString();
      }
      return out;
   }

   public void addTag(Tag tag){
      this.tags.add(tag);
   }

   public void addTags(ArrayList<Tag> tag){
      this.tags.addAll(tag);
   }

   public void setFromUser(String fromUser) {
      this.fromUser = fromUser;
   }

   public void setToUser(String toUser) {
      this.toUser = toUser;
   }

   public void setDescription(String description) {
      this.description = description;
   }

   public void setImageFromUser(String imageFromUser){this.imageFromUser = imageFromUser; }

   public void setImageToUser(String imageToUser){this.imageToUser = imageToUser; }

}
