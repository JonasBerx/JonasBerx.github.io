package ucll.project.domain.avatar;

import java.io.InputStream;
import java.util.Map;

public interface AvatarRepository {
    // CREATE
    void addAvatar(Avatar avatar);

    // READ
    Avatar getById(int avatarId);

    // READ
    Map<String, InputStream> getByEmployeeId(int employeeId);

    // READ ALL
    Map<String, InputStream> getAll();

    // UPDATE
    void update(Avatar avatar);

    // DELETE
    void delete(Avatar avatar);
}
