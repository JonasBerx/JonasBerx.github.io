package StepDefs;

import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import ucll.project.ui.DriverHelper;

import java.util.List;

public class historySteps {

@Given("{string} is logged in")
public void is_logged_in(String string) {
    // Write code here that turns the phrase above into concrete actions
    //driver.get("thanoscar.projectweek.be/Controller?command=Index");
    throw new cucumber.api.PendingException();
}

@When("{string} goes to the homepage")
public void goes_to_the_homepage(String string) {
    throw new cucumber.api.PendingException();
}

@Then("{string} will not see an history of commendations")
public void will_not_see_an_history_of_commendations(String string) {
    // Write code here that turns the phrase above into concrete actions
    throw new cucumber.api.PendingException();
}

@Then("there will be a message")
public void there_will_be_a_message(String docString) {
    // Write code here that turns the phrase above into concrete actions
    throw new cucumber.api.PendingException();
}


@Then("{string} sees the history overview of all given commendations.")
public void sees_the_history_overview_of_all_given_commendations(String string) {
    // Write code here that turns the phrase above into concrete actions
}

}