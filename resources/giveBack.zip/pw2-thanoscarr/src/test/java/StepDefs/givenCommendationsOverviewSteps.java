package StepDefs;

import io.cucumber.java.en.Then;

public class givenCommendationsOverviewSteps {

    @Then("{string} sees an overview of his given commendations")
    public void sees_an_overview_of_his_given_commendations(String string) {
        // Write code here that turns the phrase above into concrete actions
        throw new cucumber.api.PendingException();
    }

    @Then("{string} sees a message")
    public void sees_a_message(String string, String docString) {
        // Write code here that turns the phrase above into concrete actions
        throw new cucumber.api.PendingException();
    }

}
