package StepDefs;

import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class commendationsLeftSteps {

    @When("{string} enters his profile page")
    public void enters_his_profile_page(String string) {
        // Write code here that turns the phrase above into concrete actions
        throw new cucumber.api.PendingException();
    }

    @Then("{string} can see his current remaining commendations for this month")
    public void can_see_his_current_remaining_commendations_for_this_month(String string) {
        // Write code here that turns the phrase above into concrete actions
        throw new cucumber.api.PendingException();
    }

}
