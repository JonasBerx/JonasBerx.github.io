package StepDefs;

import io.cucumber.java.Before;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class createUserSteps {

    @Given("the admin is on the register page")
    public void the_admin_is_on_the_register_page() {
//        driver.get("localhost:8080/createuser.jsp");
//        if (driver.getCurrentUrl().equals("localhost:8080/createuser.jsp")) {
//            System.out.println("User is on register.");
        throw new cucumber.api.PendingException();
//        }
    }

    @When("the admin enters {string},{string} and {string} as password")
    public void the_admin_enters_and_as_password(String firstName, String lastName, String email, String password) {
//        driver.findElement(By.id("firstname")).sendKeys(firstName);
//        driver.findElement(By.id("lastname")).sendKeys(lastName);
//        driver.findElement(By.id("email")).sendKeys(email);
//        driver.findElement(By.id("password")).sendKeys(password);
//        driver.findElement(By.id("register")).submit();
        throw new cucumber.api.PendingException();
    }

    @Then("{string} is {string}")
    public void is(String email, String registered) {
//        String register = "";
//        try {
//            driver.get("localhost:8080/createuser.jsp");
//            driver.findElement(By.xpath("/html/body/nav/div/form/button")).getText().equals("Logout");
//            register = "registered";
//        } catch (org.openqa.selenium.NoSuchElementException e) {
//            register = "not registered";
//        }
//        Assert.assertEquals(register, registered);
//        driver.quit();
        throw new cucumber.api.PendingException();
    }
}
