package StepDefs;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class notificationAppointingCommendationManagerSteps {

    @Given("an employee correctly filled in a commendation")
    public void an_employee_correctly_filled_in_a_commendation() {
        // Write code here that turns the phrase above into concrete actions
        throw new cucumber.api.PendingException();
    }

    @When("an employee sends the commendation")
    public void an_employee_sends_the_commendation() {
        // Write code here that turns the phrase above into concrete actions
        throw new cucumber.api.PendingException();
    }

    @Then("{string} receives a notification about the commendation that is send")
    public void receives_a_notification_about_the_commendation_that_is_send(String string) {
        // Write code here that turns the phrase above into concrete actions
        throw new cucumber.api.PendingException();
    }

}
