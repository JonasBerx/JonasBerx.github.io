package StepDefs;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class notificationAppointmentCommendationReceiverSteps {

    @Given("{string} correctly filled in a commendation for {string}")
    public void correctly_filled_in_a_commendation_for(String string, String string2) {
        // Write code here that turns the phrase above into concrete actions
        throw new cucumber.api.PendingException();
    }

    @When("{string} sends the commendation to {string}")
    public void sends_the_commendation_to(String string, String string2) {
        // Write code here that turns the phrase above into concrete actions
        throw new cucumber.api.PendingException();
    }

    @Then("{string} receives a notification about the commendation send to him by {string}")
    public void receives_a_notification_about_the_commendation_send_to_him_by(String string, String string2) {
        // Write code here that turns the phrase above into concrete actions
        throw new cucumber.api.PendingException();
    }

    @Given("{string} incorrectly filled in a commendation for {string}")
    public void incorrectly_filled_in_a_commendation_for(String string, String string2) {
        // Write code here that turns the phrase above into concrete actions
        throw new cucumber.api.PendingException();
    }

    @Then("{string} does not receives a notification about the commendation from {string}")
    public void does_not_receives_a_notification_about_the_commendation_from(String string, String string2) {
        // Write code here that turns the phrase above into concrete actions
        throw new cucumber.api.PendingException();
    }

    @Then("{string} sees an error message")
    public void sees_an_error_message(String string) {
        // Write code here that turns the phrase above into concrete actions
        throw new cucumber.api.PendingException();
    }

    @Given("{string} correctly filled in a commendation for {string} and {string} has no commendations left to give")
    public void correctly_filled_in_a_commendation_for_and_has_no_commendations_left_to_give(String string, String string2, String string3) {
        // Write code here that turns the phrase above into concrete actions
        throw new cucumber.api.PendingException();
    }


}
