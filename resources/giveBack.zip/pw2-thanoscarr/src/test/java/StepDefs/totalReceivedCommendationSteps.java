package StepDefs;

import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;


public class totalReceivedCommendationSteps {


    @When("{string} goes to her personal page")
    public void goes_to_her_personal_page(String string) {
        // Write code here that turns the phrase above into concrete actions
        throw new cucumber.api.PendingException();
    }

    @Then("{string} sees a total of her total received commendation")
    public void sees_a_total_of_her_total_received_commendation(String string) {
        // Write code here that turns the phrase above into concrete actions
        throw new cucumber.api.PendingException();
    }
}