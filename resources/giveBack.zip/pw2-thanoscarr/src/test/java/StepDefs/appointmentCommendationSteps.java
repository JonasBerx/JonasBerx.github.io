package StepDefs;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class appointmentCommendationSteps {
    @Given("{string} is on the homepage")
    public void is_on_the_homepage(String string) {
        // Write code here that turns the phrase above into concrete actions

    }

    @Given("{string} has {int} of commendations left")
    public void has_of_commendations_left(String string, Integer int1) {
        // Write code here that turns the phrase above into concrete actions

    }

    @When("{string} gives a commendation to a colleague")
    public void gives_a_commendation_to_a_colleague(String string) {
        // Write code here that turns the phrase above into concrete actions

    }

    @Then("{string} will be able to give that commendation.")
    public void will_be_able_to_give_that_commendation(String string) {
        // Write code here that turns the phrase above into concrete actions

    }

    @Then("the commendation is shown on the homepage.")
    public void the_commendation_is_shown_on_the_homepage() {
        // Write code here that turns the phrase above into concrete actions

    }

    @Then("{string} will not be able to give that commendation.")
    public void will_not_be_able_to_give_that_commendation(String string) {
        // Write code here that turns the phrase above into concrete actions

    }

    @Then("the commendation is not shown on the homepage.")
    public void the_commendation_is_not_shown_on_the_homepage() {
        // Write code here that turns the phrase above into concrete actions

    }

}
