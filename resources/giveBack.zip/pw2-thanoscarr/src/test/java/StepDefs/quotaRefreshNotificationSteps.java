package StepDefs;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class quotaRefreshNotificationSteps {
    @Given("{string} has any amount of commendations left")
    public void has_any_amount_of_commendations_left(String string) {
        // Write code here that turns the phrase above into concrete actions
        throw new cucumber.api.PendingException();
    }

    @When("it is {int} before the start of next month")
    public void it_is_before_the_start_of_next_month(Integer int1) {
        // Write code here that turns the phrase above into concrete actions
        throw new cucumber.api.PendingException();
    }

    @Then("{string} has received a notification")
    public void has_received_a_notification(String string) {
        // Write code here that turns the phrase above into concrete actions
        throw new cucumber.api.PendingException();
    }

    @Then("{string} receives a notification")
    public void receives_a_notification(String string) {
        // Write code here that turns the phrase above into concrete actions
        throw new cucumber.api.PendingException();
    }

    @When("it is more than {int} hours before the start of next month")
    public void it_is_more_than_hours_before_the_start_of_next_month(Integer int1) {
        // Write code here that turns the phrase above into concrete actions
        throw new cucumber.api.PendingException();
    }

    @Then("{string} doesn't receive a notification.")
    public void doesn_t_receive_a_notification(String string) {
        // Write code here that turns the phrase above into concrete actions
        throw new cucumber.api.PendingException();
    }
}
