package StepDefs;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class ableToSendCommendationSteps {


    @Given("{string} is on the home page and has enough commendations left to give")
    public void is_on_the_home_page_and_has_enough_commendations_left_to_give(String string) {
        // Write code here that turns the phrase above into concrete actions
        throw new cucumber.api.PendingException();
    }

    @When("{string} fills in the form correctly and appoints the commendation")
    public void fills_in_the_form_correctly_and_appoints_the_commendation(String string) {
        // Write code here that turns the phrase above into concrete actions
        throw new cucumber.api.PendingException();
    }

    @Then("the commendation is added on the home page")
    public void the_commendation_is_added_on_the_home_page() {
        // Write code here that turns the phrase above into concrete actions
        throw new cucumber.api.PendingException();
    }

}
