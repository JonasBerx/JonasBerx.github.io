package StepDefs;

import cucumber.api.PendingException;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class loginSteps {
    @Given("{string} is on the login page")
    public void is_on_the_login_page(String string) {
        // Write code here that turns the phrase above into concrete actions
        throw new PendingException();
    }

//    @When("{string} enters his\\/hers {string} and {string}")
//    public void enters_his_hers_and(String string, String string2, String string3) {
//        // Write code here that turns the phrase above into concrete actions
//        throw new PendingException();
//    }

    @Then("{string} will be {string}")
    public void will_be(String string, String string2) {
        // Write code here that turns the phrase above into concrete actions
        throw new PendingException();
    }

    @When("{string} enters his\\/hers {string} and {string}")
    public void entersHisHersAnd(String arg0, String arg1, String arg2) {
        throw new PendingException();
    }
}
