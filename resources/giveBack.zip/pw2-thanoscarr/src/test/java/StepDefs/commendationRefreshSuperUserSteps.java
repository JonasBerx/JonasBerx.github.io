package StepDefs;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class commendationRefreshSuperUserSteps {

    @Given("{string} is a super user")
    public void is_a_super_user(String string) {
        // Write code here that turns the phrase above into concrete actions
        throw new cucumber.api.PendingException();
    }

    @When("A new month begins")
    public void a_new_month_begins() {
        // Write code here that turns the phrase above into concrete actions
        throw new cucumber.api.PendingException();
    }

    @Then("{string} has unlimited commendations to give this month")
    public void has_unlimited_commendations_to_give_this_month(String string) {
        // Write code here that turns the phrase above into concrete actions
        throw new cucumber.api.PendingException();
    }

}
