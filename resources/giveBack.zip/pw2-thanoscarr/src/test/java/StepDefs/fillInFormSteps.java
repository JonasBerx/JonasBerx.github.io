package StepDefs;

import cucumber.api.PendingException;
import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import ucll.project.ui.DriverHelper;

/**
 * @author Ben Vandermeeren and Lisa Ramaekers
 */

public class fillInFormSteps {

    @Given("the employee is on the home page")
    public void the_employee_is_on_the_home_page() {
        // Write code here that turns the phrase above into concrete actions
        throw new PendingException();
    }

    @Given("the employee has commendations left to give")
    public void the_employee_has_commendations_left_to_give() {
        // Write code here that turns the phrase above into concrete actions
        throw new PendingException();
    }

    @When("the employee gives a valid commendation")
    public void the_employee_gives_a_valid_commendation() {
        // Write code here that turns the phrase above into concrete actions
        throw new PendingException();
    }

    @Then("the commendation is added to the home page")
    public void the_commendation_is_added_to_the_home_page() {
        // Write code here that turns the phrase above into concrete actions
        throw new PendingException();
    }

    @When("the employee did not give a correct colleague name")
    public void the_employee_did_not_give_a_correct_colleague_name() {
        // Write code here that turns the phrase above into concrete actions
        throw new PendingException();
    }

    @Then("the message for incorrect colleague name is shown")
    public void the_message_for_incorrect_colleague_name_is_shown(String docString) {
        // Write code here that turns the phrase above into concrete actions
        throw new PendingException();
    }

    @When("the employee did not mark any tags for the commendation")
    public void the_employee_did_not_mark_any_tags_for_the_commendation() {
        // Write code here that turns the phrase above into concrete actions
        throw new PendingException();
    }

    @Then("the message for not marking tags is shown")
    public void the_message_for_not_marking_tags_is_shown(String docString) {
        // Write code here that turns the phrase above into concrete actions
        throw new PendingException();
    }

    @When("the employee did marked {string} tags for the commendation")
    public void the_employee_did_marked_tags_for_the_commendation(String string) {
        // Write code here that turns the phrase above into concrete actions
        throw new PendingException();
    }

    @Then("the message for marking too many tags is shown")
    public void the_message_for_marking_too_many_tags_is_shown(String docString) {
        // Write code here that turns the phrase above into concrete actions
        throw new PendingException();
    }


}
