package StepDefs;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class receivedCommendationsOverviewSteps {

    @Given("the employee is logged in")
    public void the_employee_is_logged_in() {
        // Write code here that turns the phrase above into concrete actions
        throw new cucumber.api.PendingException();
    }

    @When("the employee arrives on his profile page")
    public void the_employee_arrives_on_his_profile_page() {
        // Write code here that turns the phrase above into concrete actions
        throw new cucumber.api.PendingException();
    }

    @Then("the employee can see an overview of the commendations they received in chronological order")
    public void the_employee_can_see_an_overview_of_the_commendations_they_received_in_chronological_order() {
        // Write code here that turns the phrase above into concrete actions
        throw new cucumber.api.PendingException();
    }

    @Then("the employee sees a message")
    public void the_employee_sees_a_message(String docString) {
        // Write code here that turns the phrase above into concrete actions
        throw new cucumber.api.PendingException();
    }


}
