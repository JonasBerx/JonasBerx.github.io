package ucll.project.ui;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;
import org.openqa.selenium.WebDriver;

import static org.junit.Assert.assertEquals;

public class HomePageTest {

    private static WebDriver driver;

    @BeforeClass
    public static void SetupDriver() {
        driver = DriverHelper.getDriver();
    }

    @AfterClass
    public static void CloseBrowser() {
        driver.close();
    }

    @Test
    public void VisitHomePageTest() {

        driver.get(Config.BASE_URL);
        assertEquals("GiveBack - Log in", driver.getTitle());

    }

}
