# Java EE starter template
## Included:
  - Simple FrontController
  - Unit test
  - Selenium tests (Chrome and FireFox)
  - Testcafe tests (A better alternative for Selenium)
  
