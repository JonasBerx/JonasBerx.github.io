package ucll.project.domain.user;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

public class UserRepositoryDb implements UserRepository {
    private Properties properties = new Properties();
    private String url = "jdbc:postgresql://databanken.ucll.be:51920/hakkaton";
    @Override
    public void createUser(User user, String password) {

    }

    @Override
    public User get(int userId) {
        return null;
    }

    @Override
    public List<User> getAll() {
        try (Connection connection = DriverManager.getConnection(url, properties);
             Statement statement = connection.createStatement()) {
            ResultSet resultSet = statement.executeQuery("SELECT * FROM user ");
            return createListFromResultset(resultSet);
        } catch (SQLException e) {
            throw new DbException(e.getMessage(), e);
        }
    }

    private List<User> createListFromResultset(ResultSet resultSet) throws SQLException {
        List<User> users = new ArrayList<>();
        while (resultSet.next()) {
            int userId = Integer.parseInt(resultSet.getString("userId"));
            String userName = resultSet.getString("userName");
            String firstName = resultSet.getString("firstName");
            String lastName = resultSet.getString("lastName");
            String email = resultSet.getString("email");
            Gender gender = Gender.valueOf(resultSet.getString("gender"));
            Role role = Role.valueOf(resultSet.getString("role"));
            User user = new User(userName, firstName, lastName, email, gender, role);
            users.add(user);
        }
        return users;
    }

    @Override
    public User loginUser(String username, String password) throws InvalidLogin {
        return null;
    }

    @Override
    public void update(User user) {

    }

    @Override
    public void delete(User user) {

    }
}
