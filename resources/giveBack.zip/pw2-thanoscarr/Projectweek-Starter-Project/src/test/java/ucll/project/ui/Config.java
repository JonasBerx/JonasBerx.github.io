package ucll.project.ui;

public class Config {
    public static final String BASE_URL = "http://localhost:8080/";



}
